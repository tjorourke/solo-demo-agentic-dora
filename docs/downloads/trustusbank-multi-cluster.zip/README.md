# TrustUsBank — DORA agentic demo (multi-cluster bundle)

Every Kubernetes manifest the demo applies, grouped by install phase.
Apply order matches the script numbering: 01 -> 02 -> 03 -> 04 -> 05 -> 06 -> 06-accesspolicy -> 07 -> 09.

Companion install scripts live at https://github.com/tjorourke/solo-demo-agentic-dora.
This bundle is the manifest dump for offline review and audit.

## Quick start

```bash
# from the bundle root
kubectl apply -f phase01-ambient/
kubectl apply -f phase02-observability/
# ... in order
```

For end-to-end install with build/load/registry orchestration, use the repo's install scripts. This bundle is for **reading and auditing** what the demo applies.

## Phases (apply in order)


### `phase01-ambient/`

Istio Ambient mesh setup: ztunnel default-deny + waypoint enrolment + initial AuthorizationPolicy.

- `allow-agents-to-mcp.yaml` — ALLOW rule: kagent SAs may call MCP servers
- `deny-all-cross-ns.yaml` — default-deny AuthorizationPolicy applied to the bank-* namespaces
- `ztunnel-log-level.yaml` — (see file)

### `phase01-attacker/`

The mock-attacker pod (C2 sink) + the egress-block AuthorizationPolicy that defeats it.

- `deny-egress-to-attacker.yaml` — the single deny rule that defeats the rug-pull at L4 (bank-* -> external-attacker)
- `mock-attacker.yaml` — the C2 sink Deployment + Service (in external-attacker ns, deliberately not ambient)

### `phase02-observability/`

Prometheus + Loki + Tempo + Grafana + Alertmanager + MailHog (SOC inbox) + OTel + the PrometheusRules that fire DORA alerts.

- `agentgateway-podmonitor.yaml` — PodMonitor on agentgateway pods
- `alertmanager-email.yaml` — AlertmanagerConfig routing the demo's alerts to MailHog over plain SMTP
- `authz-deny-alert.yaml` — PodMonitor on ztunnel + PrometheusRule that fires IstioAuthZDeny + BankToAttackerAttempt
- `istio-telemetry.yaml` — Telemetry CR routing mesh telemetry to the OTel collector
- `kagent-accesspolicy-deny-alert.yaml` — PodMonitor on per-agent waypoints + KagentAccessPolicyDeny rule
- `mailhog.yaml` — the MailHog SMTP catcher (SOC inbox)
- `values/loki.yaml` — (see file)
- `values/otel-collector.yaml` — (see file)
- `values/prometheus.yaml` — (see file)
- `values/tempo.yaml` — (see file)

### `phase03-registry/`

Agentregistry — Solo's container/MCP package registry, for signing-aware MCP image publication.

- `artefacts/account-mcp.yaml` — (see file)
- `artefacts/currency-converter.yaml` — (see file)
- `artefacts/ticket-mcp.yaml` — (see file)
- `artefacts/transaction-mcp.yaml` — (see file)

### `phase04-mcp-servers/`

The three internal MCP servers (account / transaction / ticket) + the vendor's currency-converter.

- `account-mcp.yaml` — account-mcp Deployment + Service
- `currency-converter.yaml` — the vendor MCP server — gets swapped to the rug-pull image during the attack
- `ticket-mcp.yaml` — ticket-mcp Deployment + Service
- `transaction-mcp.yaml` — transaction-mcp Deployment + Service

### `phase05-agentgateway/`

agentgateway data plane + the AgentgatewayBackend/Policy CRs that gate every MCP tool call.

- `backends.yaml` — (see file)
- `gateway.yaml` — (see file)
- `httproutes.yaml` — (see file)
- `prompt-guard.yaml` — (see file)
- `rate-limit.yaml` — (see file)
- `tool-allowlist.yaml` — (see file)
- `tracing.yaml` — (see file)

### `phase06-kagent/`

Solo Enterprise for kagent: Agent CRs (support-bot / fraud-bot / triage-bot), ModelConfig, RemoteMCPServers.

- `agent-fraud-bot.yaml` — fraud-bot Agent CR — risk analysis from transactions
- `agent-support-bot.yaml` — support-bot Agent CR — customer-facing, calls all 3 internal MCPs + currency-converter
- `agent-triage-bot.yaml` — triage-bot Agent CR — escalation/ticket flow
- `modelconfig.yaml` — ModelConfig (anthropic-haiku)
- `remote-mcp-servers.yaml` — the 4 RemoteMCPServer entries (account / transaction / ticket / currency-converter)
- `telemetry.yaml` — agent-side Telemetry config -> OTel

### `phase06-kagent-accesspolicy/`

Defence layer 3: AccessPolicy CRs that whitelist which identities may invoke each Agent at the per-agent waypoint.

- `accesspolicy-support-bot-currency.yaml` — AccessPolicy CRs for support-bot + fraud-bot (defence layer 3)

### `phase07-a2a/`

Cross-namespace AuthorizationPolicies for agent-to-agent traffic.

- `tenant-isolation.yaml` — cross-namespace A2A AuthorizationPolicies

### `phase09-frontend/`

The customer-facing chatbot (nginx + SPA) — A2A JSON-RPC client against support-bot.

- `chatbot.yaml` — the chatbot Deployment + Service (nginx + SPA, A2A JSON-RPC client)

### `multi/`

Multi-cluster glue: the lateral-hack EndpointSlices that point cross-cluster service stubs at remote NodePorts.

- `lateral-hack.yaml` — manual EndpointSlices that wire cross-cluster service stubs to remote NodePorts (lateral hack)

### `dex/`

dex OIDC IdP helm values — single static user, in-memory storage.

- `values.yaml` — dex IdP helm values — single static user, in-memory storage

### `oauth2-proxy/`

oauth2-proxy helm values template — front-door that intercepts /oauth2/* on the kagent UI.

- `values.template.yaml` — oauth2-proxy helm values template — substituted with secrets at install time

### `kagent-enterprise/`

Slim helm values for the kagent-enterprise chart (OIDC + RBAC + resource pruning).

- `values-slim.yaml` — kagent-enterprise helm values — slim profile (OIDC + RBAC + resource pruning)

---

## CRD reference (every kind in this bundle)

| Kind | API group | Role in the demo |
|---|---|---|
| `Namespace` | core | Tenancy boundary. Several are labelled `istio.io/dataplane-mode=ambient` so workloads are enrolled in ztunnel. |
| `ServiceAccount` | core | Identity. SPIFFE prefix `cluster.local/ns/<ns>/sa/<sa>` is built from this. |
| `Service` / `Deployment` | core / apps | Standard workload primitives. |
| `EndpointSlice` | discovery.k8s.io | Used by `multi/lateral-hack.yaml` to plant cross-cluster endpoints pointing at NodePorts. |
| `ConfigMap` | core | Holds rendered configs (e.g. kagent-ui nginx, OTel pipeline). |
| `Gateway` / `HTTPRoute` | gateway.networking.k8s.io | Per-agent waypoint Gateways + routes. Also east/west GWs (multi-cluster). |
| `AuthorizationPolicy` | security.istio.io | ALLOW/DENY at L4 by SPIFFE identity or by source namespace. Applied by `scripts/policies-on.sh`. |
| `Telemetry` | telemetry.istio.io | Routes mesh telemetry to the OTel collector. |
| `Agent` | kagent.dev/v1alpha2 | Declarative agent (system prompt + tools list). kagent generates a Deployment + Service per Agent. |
| `ModelConfig` | kagent.dev/v1alpha2 | LLM provider + model + API key reference. |
| `RemoteMCPServer` | kagent.dev/v1alpha2 | External MCP server URL + tool list. Resolved by an Agent's tool list. |
| `MCPServer` | kagent.dev | In-cluster MCP server (kagent runs the pod itself; alternative to RemoteMCPServer). |
| `AccessPolicy` | policy.kagent-enterprise.solo.io | **Enterprise-only.** Declares who may invoke an Agent (UserGroup / ServiceAccount / Agent subject). |
| `EnterpriseAgentgatewayPolicy` | enterpriseagentgateway.solo.io | Auto-generated from AccessPolicy. Targets a per-agent waypoint Gateway. CEL on `source.identity.*`. |
| `AgentgatewayBackend` | agentgateway.dev | Declares an MCP upstream (one per MCP server). |
| `AgentgatewayPolicy` | agentgateway.dev | L7 policy attached to a Gateway/HTTPRoute. CEL on `mcp.method`, `mcp.tool.name`, `source.identity`. |
| `PodMonitor` / `PrometheusRule` / `AlertmanagerConfig` | monitoring.coreos.com | Observability. `KagentAccessPolicyDeny` fires on waypoint 403s, routes to MailHog. |
| `ServiceMeshController` | operator.gloo.solo.io | **Multi-cluster bundle.** Gloo Operator's declarative mesh-install CR (one per cluster). Replaces 4 helm charts. |
| `Workspace` / `WorkspaceSettings` / `KubernetesCluster` | admin.gloo.solo.io | **Multi-cluster bundle.** Solo management-plane primitives. |

---

## Three-layer defence

This bundle has all three rug-pull defence layers:

1. **Image signing (admission)** — cosign signatures on every MCP image; admission controller rejects unsigned. (`phase03-registry/` shows the publisher path; only present in the multi-cluster bundle.)
2. **agentgateway policy (gateway)** — `AgentgatewayPolicy` on the agentgateway's HTTPRoutes restricts which MCP tools each Agent may invoke. (`phase05-agentgateway/`)
3. **kagent AccessPolicy (agent runtime)** — `AccessPolicy` on each Agent at the per-agent waypoint denies callers the policy doesn't list. (`phase06-kagent-accesspolicy/`)

Run any combination of `scripts/policies-on.sh` and `scripts/policies-kagent-on.sh` to demonstrate layer 2 and 3 independently.
