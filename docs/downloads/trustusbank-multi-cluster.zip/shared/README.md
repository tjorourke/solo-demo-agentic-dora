# `shared/` — applied to all three clusters

Files in this folder apply to **every cluster** in the multi-cluster
install (trustusbank-edge, trustusbank-bank, trustusbank-vendor).

| File | Purpose |
|---|---|
| `00-namespaces-and-labels.yaml` | Workload namespaces with `istio.io/dataplane-mode=ambient` AND `topology.istio.io/network=<cluster>` labels (the network label is what lets istiod classify cross-cluster pods). |
| `01-cacerts-secret.example.yaml` | Template for the `cacerts` Secret in `istio-system` — holds the per-cluster intermediate CA. All three intermediates MUST be signed with SAN `spiffe://cluster.local/...`. |
| `02-solo-istio-license.example.yaml` | Template for the `solo-istio-license` Secret in `istio-system`. Must be an **enterprise** (non-trial) Solo Mesh license — the trial license has `product: gloo-trial` and istiod-gloo rejects it for the MultiCluster feature. |
| `03-servicemeshcontroller.example.yaml` | The `ServiceMeshController` CR per cluster — declares cluster name, network, trust domain (`cluster.local` on every cluster). Gloo Operator reconciles this into the istiod / ztunnel / istio-cni Deployments. |

The CA + license Secrets are templated because their content is
environment-specific. Place real values where the placeholder shows.
