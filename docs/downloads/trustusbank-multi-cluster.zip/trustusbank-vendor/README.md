# `trustusbank-vendor/` — Vendor tier — currency-converter (rug-pull target) + mock-attacker

Manifests in this folder are applied to **the `trustusbank-vendor` cluster only**.

Apply order (numeric prefix matches `shared/` ordering — `shared/`
applies first):

## `01-peering/`

- `eastwest-gateway.yaml`
- `peer-trustusbank-bank.yaml`
- `peer-trustusbank-edge.yaml`

## `02-remote-secrets/`

- `istio-remote-secret-trustusbank-bank.example.yaml`
- `istio-remote-secret-trustusbank-edge.example.yaml`

## `10-currency-converter/`

- `currency-converter.yaml`

## `11-attacker/`

- `deny-egress-to-attacker.yaml`
- `mock-attacker.yaml`

